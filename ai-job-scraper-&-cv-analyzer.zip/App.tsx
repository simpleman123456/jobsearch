import React, { useState, useCallback, useRef } from 'react';
import { findJobsByQuery, findJobsByCv } from './services/geminiService';
import { JobListing, GroundingChunk } from './types';
import JobCard from './components/JobCard';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorDisplay from './components/ErrorDisplay';
import { SearchIcon, LinkIcon, UploadCloudIcon, FileTextIcon } from './components/icons';
import { useTranslation } from './hooks/useTranslation';
import LanguageSelector from './components/LanguageSelector';


type SearchMode = 'query' | 'cv';

const countries = [
  "Australia", "Canada", "China", "France", "Germany", "India", "Japan", "Singapore", "South Korea", "United Kingdom", "United States", "Remote"
];

const App: React.FC = () => {
  const { t } = useTranslation();
  const [searchMode, setSearchMode] = useState<SearchMode>('query');
  const [query, setQuery] = useState<string>('');
  const [country, setCountry] = useState<string>('United States');
  const [industry, setIndustry] = useState<string>('');
  const [jobLevel, setJobLevel] = useState<string>('');
  const [cvFile, setCvFile] = useState<File | null>(null);

  const [jobs, setJobs] = useState<JobListing[]>([]);
  const [sources, setSources] = useState<GroundingChunk[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hasSearched, setHasSearched] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSearch = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    setJobs([]);
    setSources([]);
    setHasSearched(true);

    try {
      let result;
      if (searchMode === 'cv') {
        if (!cvFile) {
          throw new Error("ERROR_CV_REQUIRED");
        }
        result = await findJobsByCv({ cvFile, country, query });
      } else {
        if (!query.trim()) {
          throw new Error("ERROR_KEYWORDS_REQUIRED");
        }
        result = await findJobsByQuery({ query, country, industry, jobLevel });
      }
      setJobs(result.jobs);
      setSources(result.sources);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("ERROR_UNKNOWN");
      }
    } finally {
      setIsLoading(false);
    }
  }, [query, searchMode, cvFile, country, industry, jobLevel]);

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        setError("ERROR_INVALID_FILE_TYPE");
        setCvFile(null);
        if (fileInputRef.current) {
          fileInputRef.current.value = "";
        }
        return;
      }
      setError(null);
      setCvFile(file);
    }
  };

  const isSearchDisabled = isLoading || (searchMode === 'cv' && !cvFile) || (searchMode === 'query' && !query.trim());


  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <main className="container mx-auto px-4 py-8">
        <header className="relative text-center mb-8">
          <div className="absolute top-0 right-0">
             <LanguageSelector />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-teal-500">
            {t('appTitle')}
          </h1>
          <p className="text-gray-400 mt-2">{t('appSubtitle')}</p>
        </header>

        <div className="max-w-3xl mx-auto mb-12 bg-gray-800/50 p-6 rounded-xl border border-gray-700">
            {/* Search Mode Toggle */}
            <div className="flex justify-center mb-6">
                <div className="bg-gray-800 p-1 rounded-full flex">
                    <button onClick={() => setSearchMode('query')} className={`px-6 py-2 rounded-full transition-colors duration-300 ${searchMode === 'query' ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}>{t('searchByQuery')}</button>
                    <button onClick={() => setSearchMode('cv')} className={`px-6 py-2 rounded-full transition-colors duration-300 ${searchMode === 'cv' ? 'bg-cyan-600 text-white' : 'text-gray-400 hover:bg-gray-700'}`}>{t('analyzeCv')}</button>
                </div>
            </div>

            {/* Search Inputs */}
            {searchMode === 'query' ? (
                <div className="space-y-4">
                    <div>
                        <label htmlFor="query" className="block text-sm font-medium text-gray-400 mb-1">{t('jobTitleLabel')}</label>
                        <input
                            id="query"
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            onKeyPress={handleKeyPress}
                            placeholder={t('jobTitlePlaceholder')}
                            className="w-full p-3 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:outline-none transition-colors"
                            disabled={isLoading}
                        />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="flex-1">
                            <label htmlFor="query-country" className="block text-sm font-medium text-gray-400 mb-1">{t('countryLabel')}</label>
                            <select id="query-country" value={country} onChange={(e) => setCountry(e.target.value)} className="w-full p-3 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:outline-none transition-colors">
                                {countries.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                        <div className="flex-1">
                            <label htmlFor="industry" className="block text-sm font-medium text-gray-400 mb-1">{t('industryLabel')}</label>
                            <input
                                id="industry"
                                type="text"
                                value={industry}
                                onChange={(e) => setIndustry(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder={t('industryPlaceholder')}
                                className="w-full p-3 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:outline-none transition-colors"
                                disabled={isLoading}
                            />
                        </div>
                        <div className="flex-1">
                            <label htmlFor="job-level" className="block text-sm font-medium text-gray-400 mb-1">{t('jobLevelLabel')}</label>
                            <input
                                id="job-level"
                                type="text"
                                value={jobLevel}
                                onChange={(e) => setJobLevel(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder={t('jobLevelPlaceholder')}
                                className="w-full p-3 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:outline-none transition-colors"
                                disabled={isLoading}
                            />
                        </div>
                    </div>
                </div>
            ) : (
                <div className="space-y-4">
                    <label 
                        htmlFor="cv-upload" 
                        className="w-full flex flex-col items-center justify-center p-6 bg-gray-800 border-2 border-dashed border-gray-600 rounded-lg cursor-pointer hover:bg-gray-700 hover:border-cyan-500 transition-colors"
                    >
                        <UploadCloudIcon className="w-10 h-10 text-gray-500 mb-2" />
                        <span className="font-semibold text-cyan-400">{t('uploadCvLabel')}</span>
                        <span className="text-sm text-gray-400">{t('pdfOnly')}</span>
                    </label>
                    <input id="cv-upload" type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept=".pdf" />

                    {cvFile && (
                        <div className="flex items-center justify-center bg-gray-700/50 p-3 rounded-md text-sm">
                            <FileTextIcon className="w-5 h-5 mr-3 text-cyan-400" />
                            <span className="text-gray-300">{cvFile.name}</span>
                        </div>
                    )}
                    
                    <div className="flex flex-col sm:flex-row gap-4">
                         <div className="flex-1">
                            <label htmlFor="country" className="block text-sm font-medium text-gray-400 mb-1">{t('countryLabel')}</label>
                            <select id="country" value={country} onChange={(e) => setCountry(e.target.value)} className="w-full p-3 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:outline-none transition-colors">
                                {countries.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>
                         <div className="flex-1">
                            <label htmlFor="cv-query" className="block text-sm font-medium text-gray-400 mb-1">{t('keywordsLabel')}</label>
                            <input
                                id="cv-query"
                                type="text"
                                value={query}
                                onChange={(e) => setQuery(e.target.value)}
                                onKeyPress={handleKeyPress}
                                placeholder={t('keywordsPlaceholder')}
                                className="w-full p-3 bg-gray-800 border-2 border-gray-700 rounded-lg focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 focus:outline-none transition-colors"
                                disabled={isLoading}
                            />
                        </div>
                    </div>
                </div>
            )}
            
            <div className="mt-6">
                <button
                  onClick={handleSearch}
                  disabled={isSearchDisabled}
                  className="w-full flex items-center justify-center bg-cyan-600 text-white font-semibold py-3 px-6 rounded-full hover:bg-cyan-700 disabled:bg-gray-600 disabled:cursor-not-allowed transition-all duration-300 text-lg"
                >
                  <SearchIcon className="w-6 h-6 mr-2" />
                  <span>{isLoading ? t('searching') : (searchMode === 'cv' ? t('analyzeAndFindJobs') : t('findJobs'))}</span>
                </button>
            </div>
        </div>

        <div className="max-w-6xl mx-auto">
          {isLoading && <LoadingSpinner />}
          {error && <ErrorDisplay message={error} />}
          
          {!isLoading && !error && hasSearched && jobs.length === 0 && (
            <div className="text-center py-12">
              <h2 className="text-2xl font-semibold text-gray-400">{t('noJobsFound')}</h2>
              <p className="text-gray-500 mt-2">{t('refineSearch')}</p>
            </div>
          )}

          {jobs.length > 0 && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {jobs.map((job, index) => (
                  <JobCard key={`${job.url}-${index}`} job={job} />
                ))}
              </div>
              {sources.length > 0 && (
                <div className="mt-12 bg-gray-800/50 border border-gray-700 rounded-lg p-6">
                   <h3 className="text-lg font-semibold text-cyan-400 mb-4 flex items-center">
                    <LinkIcon className="w-5 h-5 mr-2" />
                    {t('dataSources')}
                  </h3>
                  <ul className="space-y-2">
                    {sources.map((source, index) => (
                        source.web && (
                             <li key={index} className="text-sm">
                                <a href={source.web.uri} target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-cyan-400 transition-colors duration-200 underline decoration-dotted">
                                    {source.web.title || source.web.uri}
                                </a>
                            </li>
                        )
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}

          {!hasSearched && !isLoading && (
            <div className="text-center py-12 text-gray-500">
                <p>{t('getStarted')}</p>
            </div>
          )}

        </div>
      </main>
    </div>
  );
};

export default App;
