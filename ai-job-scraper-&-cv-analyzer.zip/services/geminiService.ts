import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { JobListing, GroundingChunk } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set. Please set it in your environment.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Parses the raw API response, handles potential markdown formatting, and extracts job listings and sources.
 * @param response The response object from the Gemini API.
 * @returns An object containing the job listings and sources.
 */
const parseApiResponse = (response: GenerateContentResponse): { jobs: JobListing[]; sources: GroundingChunk[] } => {
  const textResponse = response.text;
  const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
  const sources = (groundingMetadata?.groundingChunks || []) as GroundingChunk[];

  if (!textResponse) {
    throw new Error("ERROR_EMPTY_RESPONSE");
  }

  // Defensive parsing for JSON that might be wrapped in markdown
  let jsonString = textResponse.trim();
  if (jsonString.startsWith('```json')) {
    jsonString = jsonString.slice(7);
  }
  if (jsonString.endsWith('```')) {
    jsonString = jsonString.slice(0, -3);
  }
  jsonString = jsonString.trim();

  try {
    const jobs: JobListing[] = JSON.parse(jsonString);
    if (!Array.isArray(jobs)) {
      throw new Error("ERROR_INVALID_JSON_ARRAY");
    }
    return { jobs, sources };
  } catch (e) {
    console.error("Failed to parse JSON response:", textResponse);
    throw new Error("ERROR_UNEXPECTED_FORMAT");
  }
};

const generateQueryPrompt = (query: string, country: string, industry: string, jobLevel: string): string => {
    let promptQuery = `Your task is to find relevant, up-to-date job listings for "${query}".`;
        
    const filterParts = [];
    if (country) filterParts.push(`located in "${country}"`);
    if (industry.trim()) filterParts.push(`in the "${industry}" industry`);
    if (jobLevel.trim()) filterParts.push(`at the "${jobLevel}" level`);

    if (filterParts.length > 0) {
        promptQuery += ` The listings must be ${filterParts.join(' and ')}.`;
    }

    return `
        You are an expert job scraping agent. ${promptQuery}
        
        Use Google Search to find at least 5 job postings that match all the specified criteria.
        For each job, extract the following information:
        - jobTitle: The title of the job.
        - companyName: The name of the company hiring.
        - location: The city and country of the job.
        - description: A brief, one or two-sentence summary of the job's key responsibilities. Do not include citation markers like [1], [2, 3] in this field.
        - url: The direct URL to the job posting.

        Return the results as a stringified JSON array of objects. Do not include any text, pleasantries, or markdown formatting (like \`\`\`json) before or after the JSON array. Your entire output must be only the raw JSON array string.
    `;
};


const generateCvPrompt = (country: string, query: string): string => {
    const queryPart = query.trim() ? `Also consider the user's specific keywords for refinement: "${query}".` : '';
    return `
    You are an expert career advisor and job scraping agent. Your primary task is to analyze the attached CV and find relevant, up-to-date job listings.
    ${queryPart}
    The job postings must be located in: "${country}".

    Based on the CV's content (experience, skills), use Google Search to find at least 5 job postings that are an excellent match.
    For each job, extract the following information:
    - jobTitle: The title of the job.
    - companyName: The name of the company hiring.
    - location: The city and country of the job.
    - description: A brief, one or two-sentence summary of the job's key responsibilities. Do not include citation markers like [1], [2, 3] in this field.
    - url: The direct URL to the job posting.

    Return the results as a stringified JSON array of objects. Do not include any text, pleasantries, or markdown formatting (like \`\`\`json) before or after the JSON array. Your entire output must be only the raw JSON array string.
  `;
};

/**
 * Converts a File object into a GoogleGenAI.Part object for multimodal requests.
 * @param file The file to convert.
 * @returns A promise that resolves to a Part object.
 */
async function fileToGenerativePart(file: File) {
    const base64EncodedDataPromise = new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
      reader.readAsDataURL(file);
    });
    return {
      inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
    };
}

/**
 * Finds jobs based on a text query with filters.
 * @param options An object containing the query and optional filters.
 * @returns A promise that resolves to the jobs and sources.
 */
export const findJobsByQuery = async (options: { query: string; country: string; industry: string; jobLevel: string; }): Promise<{ jobs: JobListing[]; sources: GroundingChunk[] }> => {
  const { query, country, industry, jobLevel } = options;

  if (!query.trim()) {
    return { jobs: [], sources: [] };
  }

  const prompt = generateQueryPrompt(query, country, industry, jobLevel);

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        temperature: 0.2,
      },
    });
    
    return parseApiResponse(response);

  } catch (error) {
    console.error("Error fetching jobs from Gemini API:", error);
    if (error instanceof Error) {
        throw new Error(`API_ERROR: ${error.message}`);
    }
    throw new Error("ERROR_UNKNOWN");
  }
};

/**
 * Finds jobs by analyzing a CV file.
 * @param options An object containing the CV file, country, and an optional query.
 * @returns A promise that resolves to the jobs and sources.
 */
export const findJobsByCv = async (options: { cvFile: File; country: string; query: string; }): Promise<{ jobs: JobListing[]; sources: GroundingChunk[] }> => {
    const { cvFile, country, query } = options;
    
    try {
        const cvPart = await fileToGenerativePart(cvFile);
        const textPart = { text: generateCvPrompt(country, query) };

        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: { parts: [cvPart, textPart] },
            config: {
                tools: [{ googleSearch: {} }],
                temperature: 0.2,
            },
        });

        return parseApiResponse(response);

    } catch (error) {
        console.error("Error fetching jobs from Gemini API:", error);
        if (error instanceof Error) {
            throw new Error(`API_ERROR: ${error.message}`);
        }
        throw new Error("ERROR_UNKNOWN");
    }
};
