
export interface JobListing {
  jobTitle: string;
  companyName: string;
  location: string;
  description: string;
  url: string;
}

export interface GroundingChunk {
  web: {
    uri: string;
    title: string;
  };
}
