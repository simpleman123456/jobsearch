import { useState, useEffect, useCallback } from 'react';
import { useLanguage } from '../context/LanguageContext';

// Statically import all translation files as JavaScript modules.
// This is more robust than using JSON imports with assertions.
import en from '../locales/en.js';
import zh from '../locales/zh.js';
import ja from '../locales/ja.js';
import ko from '../locales/ko.js';
import hi from '../locales/hi.js';
import es from '../locales/es.js';
import fr from '../locales/fr.js';

// Define a type for our translation files
type Translations = { [key: string]: string };

const allTranslations: Record<string, Translations> = {
  en,
  zh,
  ja,
  ko,
  hi,
  es,
  fr,
};

export const useTranslation = () => {
  const { language } = useLanguage();
  
  // Set initial state synchronously based on the current language
  const [translations, setTranslations] = useState<Translations>(
    allTranslations[language] || allTranslations.en
  );

  // Update translations when the language changes
  useEffect(() => {
    setTranslations(allTranslations[language] || allTranslations.en);
  }, [language]);

  const t = useCallback((key: string): string => {
    return translations[key] || key;
  }, [translations]);

  const isKey = useCallback((key: string): boolean => {
    // A more robust check for property existence
    return Object.prototype.hasOwnProperty.call(translations, key);
  }, [translations]);

  return { t, isKey, language };
};