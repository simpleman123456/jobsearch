import React from 'react';
import { JobListing } from '../types';
import { BriefcaseIcon, MapPinIcon } from './icons';
import { useTranslation } from '../hooks/useTranslation';

interface JobCardProps {
  job: JobListing;
}

const JobCard: React.FC<JobCardProps> = ({ job }) => {
  const { t } = useTranslation();
  return (
    <div className="bg-gray-800 rounded-lg shadow-lg p-6 border border-gray-700 hover:border-cyan-500 transition-all duration-300 ease-in-out transform hover:-translate-y-1">
      <div className="flex flex-col h-full">
        <h3 className="text-xl font-bold text-cyan-400 mb-2">{job.jobTitle}</h3>
        <div className="flex items-center text-gray-400 mb-2">
          <BriefcaseIcon className="w-5 h-5 mr-2" />
          <span>{job.companyName}</span>
        </div>
        <div className="flex items-center text-gray-400 mb-4">
          <MapPinIcon className="w-5 h-5 mr-2" />
          <span>{job.location}</span>
        </div>
        <p className="text-gray-300 text-sm flex-grow mb-4">{job.description}</p>
        <div className="mt-auto pt-4 border-t border-gray-700">
           <a
            href={job.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block w-full text-center bg-cyan-600 text-white font-semibold py-2 px-4 rounded-md hover:bg-cyan-700 transition-colors duration-300"
          >
            {t('viewJob')}
          </a>
        </div>
      </div>
    </div>
  );
};

export default JobCard;
