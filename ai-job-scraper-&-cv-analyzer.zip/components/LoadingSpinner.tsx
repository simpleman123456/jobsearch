import React from 'react';
import { useTranslation } from '../hooks/useTranslation';

const LoadingSpinner: React.FC = () => {
  const { t } = useTranslation();
  return (
    <div className="flex flex-col items-center justify-center space-y-4">
      <div className="w-16 h-16 border-4 border-dashed rounded-full animate-spin border-cyan-500"></div>
      <p className="text-lg text-cyan-400">{t('findingJobs')}</p>
    </div>
  );
};

export default LoadingSpinner;
