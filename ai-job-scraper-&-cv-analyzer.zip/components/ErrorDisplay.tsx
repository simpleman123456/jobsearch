import React from 'react';
import { AlertTriangleIcon } from './icons';
import { useTranslation } from '../hooks/useTranslation';

interface ErrorDisplayProps {
  message: string;
}

const ErrorDisplay: React.FC<ErrorDisplayProps> = ({ message }) => {
  const { t, isKey } = useTranslation();

  const getErrorMessage = () => {
    // If the message is a translation key, translate it.
    if (isKey(message)) {
      return t(message);
    }
    // Handle specific API error format
    if (message.startsWith('API_ERROR:')) {
        return `${t('apiErrorPrefix')} ${message.replace('API_ERROR:', '').trim()}`;
    }
    // Otherwise, display the message as is.
    return message;
  };


  return (
    <div className="bg-red-900/50 border border-red-700 text-red-300 px-4 py-3 rounded-lg relative" role="alert">
      <div className="flex">
        <div className="py-1">
          <AlertTriangleIcon className="h-6 w-6 text-red-400 mr-4"/>
        </div>
        <div>
          <strong className="font-bold">{t('errorOccurred')}</strong>
          <span className="block sm:inline ml-2">{getErrorMessage()}</span>
        </div>
      </div>
    </div>
  );
};

export default ErrorDisplay;
